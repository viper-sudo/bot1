Talisman xmpp/jabber bot!
===================


Welcome! 
----------     
Me and the [development team](http://xtreme.im/xt-about) was thinking. Talisman was a very good bot. The only problem was that it had some issues due to security among other problems.
In short out dated and not good to anyone no more.  

Information:
-----------
 


> Talisman is made from python, It      runs with the xmpp library
> allowing it to connect to a xmpp server and interact with users,  type
> into the conference or private 
>      "commands all" Without quotation marks. This version of talisman is based off of [planb's
> talisman](https://code.google.com/p/talismanppc/).  It's features are
> to administrate your Conference. It has AIML also, meaning it can talk
> to you when asked a question. Will go further into detail at a later
> date.

--------------------------------------------------

Installing:
-----------
####Download python 2 +: [Here](https://www.python.org "Python homepage")

####(optional) Notpad++: [Here](http://notepad-plus-plus.org/ "notepad++ homepage")

###Download the bot: 

 -  **Windows**: Click the zip folder on the right
 
 - **Linux**: `git clone https://github.com/XtremeTeam/Talisman-xmpp-bot.git`


------------
