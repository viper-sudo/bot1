This is an optional plugin I have experienced some errors  that causes the bot to shutdown on mobile device .so maybe give it a try.

1) copy 'questions.txt' into the static folder.
2) simply copy the quiz_plugin in plugins folder.